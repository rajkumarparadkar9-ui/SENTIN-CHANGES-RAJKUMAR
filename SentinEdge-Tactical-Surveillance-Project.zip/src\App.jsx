import React, { useState, useEffect, useRef, useCallback, memo } from 'react';
import { 
  ShieldAlert, ShieldCheck, Zap, Video, Volume2, VolumeX, MapPin, Activity, 
  Image as ImageIcon, Clock, AlertTriangle, Server, Settings, Cpu, HardDrive, 
  Network, Car, Package, Bell, BellOff, CheckCircle2, Play, RefreshCw, X, 
  Radio, Eye, Download, Search, Filter, Compass, Crosshair, Terminal, Gauge
} from 'lucide-react';
import * as tf from '@tensorflow/tfjs';
import * as blazeface from '@tensorflow-models/blazeface';
import * as cocoSsd from '@tensorflow-models/coco-ssd';

// --- ENHANCED WEB AUDIO SIREN SYNTHESIZER ---
class SirenSynthesizer {
  constructor() {
    this.ctx = null;
    this.osc1 = null;
    this.osc2 = null;
    this.gainNode = null;
    this.lfo = null;
    this.lfoGain = null;
    this.isPlaying = false;
    this.volume = 0.35;
    this.toneMode = 'wail';
  }

  init() {
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || window.webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  setVolume(val) {
    this.volume = Math.max(0, Math.min(1, val));
    if (this.gainNode && this.ctx && this.isPlaying) {
      try {
        this.gainNode.gain.setValueAtTime(this.volume, this.ctx.currentTime);
      } catch (e) {}
    }
  }

  setToneMode(mode) {
    this.toneMode = mode;
    if (this.isPlaying) {
      this.stop();
      this.start();
    }
  }

  start() {
    if (this.isPlaying) return;
    try {
      this.init();
      if (!this.ctx) return;

      const now = this.ctx.currentTime;
      
      this.gainNode = this.ctx.createGain();
      this.gainNode.gain.setValueAtTime(0.001, now);
      this.gainNode.gain.exponentialRampToValueAtTime(this.volume, now + 0.08);
      this.gainNode.connect(this.ctx.destination);

      if (this.toneMode === 'pulse') {
        this.osc1 = this.ctx.createOscillator();
        this.osc1.type = 'sawtooth';
        this.osc1.frequency.setValueAtTime(900, now);

        this.lfo = this.ctx.createOscillator();
        this.lfo.type = 'square';
        this.lfo.frequency.setValueAtTime(6.0, now);

        this.lfoGain = this.ctx.createGain();
        this.lfoGain.gain.setValueAtTime(400, now);

        this.lfo.connect(this.lfoGain);
        this.lfoGain.connect(this.osc1.frequency);
        this.osc1.connect(this.gainNode);

        this.lfo.start(now);
        this.osc1.start(now);
      } else {
        const lfoSpeed = this.toneMode === 'yelp' ? 4.5 : 2.0;
        const sweepRange = this.toneMode === 'yelp' ? 350 : 260;
        const baseFreq = this.toneMode === 'yelp' ? 800 : 720;

        this.osc1 = this.ctx.createOscillator();
        this.osc1.type = 'sawtooth';
        this.osc1.frequency.setValueAtTime(baseFreq, now);

        this.osc2 = this.ctx.createOscillator();
        this.osc2.type = 'square';
        this.osc2.frequency.setValueAtTime(baseFreq + 4, now);

        this.lfo = this.ctx.createOscillator();
        this.lfo.type = 'triangle';
        this.lfo.frequency.setValueAtTime(lfoSpeed, now);

        this.lfoGain = this.ctx.createGain();
        this.lfoGain.gain.setValueAtTime(sweepRange, now);

        this.lfo.connect(this.lfoGain);
        this.lfoGain.connect(this.osc1.frequency);
        this.lfoGain.connect(this.osc2.frequency);

        this.osc1.connect(this.gainNode);
        this.osc2.connect(this.gainNode);

        this.lfo.start(now);
        this.osc1.start(now);
        this.osc2.start(now);
      }

      this.isPlaying = true;
    } catch (e) {
      console.error("Audio error:", e);
    }
  }

  stop() {
    if (!this.isPlaying) return;
    try {
      if (this.gainNode && this.ctx) {
        const now = this.ctx.currentTime;
        this.gainNode.gain.setValueAtTime(this.gainNode.gain.value, now);
        this.gainNode.gain.exponentialRampToValueAtTime(0.0001, now + 0.12);
        setTimeout(() => {
          try {
            if (this.osc1) { this.osc1.stop(); this.osc1.disconnect(); }
            if (this.osc2) { this.osc2.stop(); this.osc2.disconnect(); }
            if (this.lfo) { this.lfo.stop(); this.lfo.disconnect(); }
            if (this.lfoGain) this.lfoGain.disconnect();
            if (this.gainNode) this.gainNode.disconnect();
          } catch(e) {}
          this.isPlaying = false;
        }, 130);
      } else {
        this.isPlaying = false;
      }
    } catch (e) {
      this.isPlaying = false;
    }
  }
}

const sirenAudio = new SirenSynthesizer();

// --- MEMOIZED CAMERA VIEW TO PREVENT ANY FLICKER / RE-RENDER ON SIREN TICKS ---
const CameraView = memo(({ title, filterClass, showOverlays, activeStream, onDetect, zoneMode, aiEnabled, camId, locationName }) => {
  const videoRef = useRef(null);
  const [points, setPoints] = useState([]);
  const [drawnPolygons, setDrawnPolygons] = useState([]);
  const [faces, setFaces] = useState([]);

  useEffect(() => {
    if (videoRef.current && activeStream) {
      videoRef.current.srcObject = activeStream;
    }
  }, [activeStream]);

  useEffect(() => {
    let model = null;
    let animationFrame = null;
    let cancelled = false;

    const loadModel = async () => {
      try {
        await tf.ready();
        model = await blazeface.load();
        if (!cancelled) {
          detectFace();
        }
      } catch (e) {
        console.error("TFJS Error:", e);
      }
    };

    const detectFace = async () => {
      if (cancelled) return;
      try {
        if (videoRef.current && videoRef.current.readyState === 4 && model) {
          const predictions = await model.estimateFaces(videoRef.current, false);
          
          if (cancelled) return;
          
          if (predictions.length > 0) {
            const video = videoRef.current;
            const mappedFaces = predictions.map(pred => {
              const start = pred.topLeft;
              const end = pred.bottomRight;
              const size = [end[0] - start[0], end[1] - start[1]];
              
              const padding = 20; 
              const x = ((start[0] - padding) / video.videoWidth) * 100;
              const y = ((start[1] - padding) / video.videoHeight) * 100;
              const w = ((size[0] + padding*2) / video.videoWidth) * 100;
              const h = ((size[1] + padding*2) / video.videoHeight) * 100;
              
              return { 
                x: Math.max(0, Math.min(100 - w, x)), 
                y: Math.max(0, Math.min(100 - h, y)), 
                w: Math.min(100, w), 
                h: Math.min(100, h) 
              };
            });
            setFaces(mappedFaces);
            if (onDetect) {
              onDetect({
                detected: true,
                camId,
                title,
                location: locationName,
                classification: 'Human Intruder',
                confidence: '98.4%',
                severity: 'CRITICAL',
                details: 'Unauthorized human face biometric signature acquired in restricted security perimeter.'
              });
            }
          } else {
            setFaces([]);
            if (onDetect) {
              onDetect({ detected: false, camId });
            }
          }
        }
      } catch (e) {
        console.error("Face detection error:", e);
      }
      if (!cancelled) {
        animationFrame = setTimeout(detectFace, 66);
      }
    };

    if (activeStream && showOverlays && aiEnabled) {
      loadModel();
    } else {
      setFaces([]);
      if (onDetect) onDetect({ detected: false, camId });
    }

    return () => {
      cancelled = true;
      if (animationFrame) clearTimeout(animationFrame);
      if (onDetect) onDetect({ detected: false, camId });
      if (model) {
        try { model.dispose(); } catch(e) {}
      }
    };
  }, [activeStream, showOverlays, aiEnabled, camId, title, locationName, onDetect]);

  const handleCanvasClick = (e) => {
    if (!showOverlays) return;
    const rect = e.currentTarget.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * 100;
    const y = ((e.clientY - rect.top) / rect.height) * 100;
    setPoints(prev => [...prev, `${x.toFixed(1)},${y.toFixed(1)}`]);
  };

  const handleRightClick = (e) => {
    e.preventDefault();
    if (points.length > 2) {
      setDrawnPolygons(prev => [...prev, { type: zoneMode, points: points.join(' ') }]);
    }
    setPoints([]);
  };

  return (
    <div className="relative overflow-hidden rounded-xl border border-slate-800/80 bg-slate-950/90 shadow-2xl flex flex-col group video-stable-container">
      {/* HUD Header Overlay */}
      <div className="absolute top-0 left-0 w-full bg-gradient-to-b from-black/85 via-black/60 to-transparent px-3 py-2 flex justify-between items-center z-30 text-[11px] font-mono border-b border-slate-800/50">
        <div className="flex items-center gap-2">
          <div className="w-2 h-2 rounded-full bg-emerald-500 shadow-[0_0_8px_#10b981]"></div>
          <span className="text-white font-bold tracking-wider">{camId}</span>
          <span className="text-slate-400 border-l border-slate-700 pl-2">{locationName}</span>
        </div>
        <div className="flex items-center gap-3 text-slate-400">
          <span className="text-emerald-400 font-bold">1080P/25FPS</span>
          <span className="bg-slate-900/90 border border-slate-700 px-1.5 py-0.5 rounded text-[10px] text-slate-300">AI: {showOverlays && aiEnabled ? 'ACTIVE' : 'STANDBY'}</span>
        </div>
      </div>
      
      {/* Main Video View */}
      <div className="flex-1 relative w-full h-full min-h-[240px] bg-slate-950 flex items-center justify-center">
        <video 
          ref={videoRef} 
          autoPlay 
          playsInline 
          muted 
          className={`w-full h-full object-cover ${filterClass}`} 
          style={{ transform: 'scaleX(-1)' }} 
        />

        {/* HUD Crosshairs on Corners */}
        <div className="absolute top-8 left-3 w-4 h-4 border-t-2 border-l-2 border-emerald-500/60 pointer-events-none"></div>
        <div className="absolute top-8 right-3 w-4 h-4 border-t-2 border-r-2 border-emerald-500/60 pointer-events-none"></div>
        <div className="absolute bottom-3 left-3 w-4 h-4 border-b-2 border-l-2 border-emerald-500/60 pointer-events-none"></div>
        <div className="absolute bottom-3 right-3 w-4 h-4 border-b-2 border-r-2 border-emerald-500/60 pointer-events-none"></div>

        {showOverlays && aiEnabled && (
          <>
            <svg 
              onClick={handleCanvasClick} 
              onContextMenu={handleRightClick}
              className="absolute inset-0 w-full h-full z-10 pointer-events-auto cursor-crosshair" 
              preserveAspectRatio="none" 
              viewBox="0 0 100 100"
            >
              <polygon points="10,90 90,90 75,50 25,50" className="fill-red-500/10 stroke-red-500/80 stroke-[0.5] transition-all hover:fill-red-500/25" />
              {drawnPolygons.map((p, i) => (
                <polygon key={i} points={p.points} className={`${p.type === 'red' ? 'fill-red-500/20 stroke-red-500' : p.type === 'yellow' ? 'fill-yellow-500/20 stroke-yellow-500' : 'fill-blue-500/20 stroke-blue-500'} stroke-[0.5]`} />
              ))}
              {points.length > 0 && (
                <polyline points={points.join(' ')} className="fill-none stroke-white stroke-[0.5] stroke-dasharray-2" />
              )}
            </svg>

            {faces.map((faceBox, idx) => (
              <div key={idx} className="absolute border-2 border-red-500 shadow-[0_0_15px_#ef4444] z-20 pointer-events-none transition-all duration-75"
                style={{ 
                  left: `${100 - faceBox.x - faceBox.w}%`, 
                  top: `${faceBox.y}%`, 
                  width: `${faceBox.w}%`, 
                  height: `${faceBox.h}%` 
                }}>
                <div className="absolute -top-6 left-[-2px] px-1.5 py-0.5 text-[10px] font-bold font-mono text-white bg-red-600 flex items-center gap-1 shadow-md whitespace-nowrap">
                  <AlertTriangle className="w-3 h-3"/> INTRUDER: 98.4%
                </div>
                <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-8 h-8 border border-red-400 rounded-full animate-ping opacity-60"></div>
                <div className="absolute top-1/2 left-1/2 w-3 h-[1px] -translate-x-1/2 -translate-y-1/2 bg-red-400"></div>
                <div className="absolute top-1/2 left-1/2 h-3 w-[1px] -translate-x-1/2 -translate-y-1/2 bg-red-400"></div>
              </div>
            ))}
          </>
        )}
        <div className="absolute top-0 left-0 w-full h-0.5 bg-emerald-400/50 shadow-[0_0_10px_#10b981] z-20 animate-[scan_4s_linear_infinite] pointer-events-none"></div>
      </div>
    </div>
  );
});

// --- MEMOIZED GENERIC LIVE DETECTION VIEW (COCO-SSD) ---
const LiveDetectionView = memo(({ title, icon: Icon, type, activeStream, color, alertTitle, onDetect, alarmRemaining, alarmDuration }) => {
  const videoRef = useRef(null);
  const [predictions, setPredictions] = useState([]);

  useEffect(() => {
    if (videoRef.current && activeStream) {
      videoRef.current.srcObject = activeStream;
    }
  }, [activeStream]);

  useEffect(() => {
    let model = null;
    let animationFrame = null;
    let cancelled = false;

    const loadModel = async () => {
      try {
        await tf.ready();
        model = await cocoSsd.load();
        if (!cancelled) {
          detectFrame();
        }
      } catch (e) {
        console.error("COCO-SSD Error:", e);
      }
    };

    const detectFrame = async () => {
      if (cancelled) return;
      try {
        if (videoRef.current && videoRef.current.readyState === 4 && model) {
          const preds = await model.detect(videoRef.current);
          
          if (cancelled) return;
          
          let filtered = [];
          const vehicles = ['car', 'truck', 'bus', 'motorcycle', 'bicycle'];
          
          if (type === 'vehicle') {
             filtered = preds.filter(p => vehicles.includes(p.class));
          } else if (type === 'object') {
             filtered = preds.filter(p => p.class !== 'person' && !vehicles.includes(p.class));
          }
          
          const video = videoRef.current;
          const mapped = filtered.map(p => {
             const [x, y, w, h] = p.bbox;
             return {
               class: p.class,
               score: Math.round(p.score * 100),
               x: (x / video.videoWidth) * 100,
               y: (y / video.videoHeight) * 100,
               w: (w / video.videoWidth) * 100,
               h: (h / video.videoHeight) * 100
             };
          });
          setPredictions(mapped);
          if (onDetect) {
            if (mapped.length > 0) {
              onDetect({
                detected: true,
                camId: type === 'vehicle' ? 'CAM-04 (ANPR Gate)' : 'CAM-03 (Depot Vault)',
                title: type === 'vehicle' ? 'Gate ANPR Telemetry' : 'Perimeter Vault Sector',
                location: type === 'vehicle' ? 'South Checkpoint Entry' : 'Yellow Security Depot B',
                classification: type === 'vehicle' ? `Vehicle (${mapped[0].class.toUpperCase()})` : `Unattended Item (${mapped[0].class.toUpperCase()})`,
                confidence: `${mapped[0].score}%`,
                severity: type === 'vehicle' ? 'WARNING' : 'CRITICAL',
                details: type === 'vehicle' 
                  ? `Identified vehicle classification: ${mapped[0].class.toUpperCase()} entering sector. ANPR license telemetry scanning.`
                  : `Stationary object (${mapped[0].class.toUpperCase()}) observed in yellow perimeter zone without attendant.`
              });
            } else {
              onDetect({ detected: false, camId: type === 'vehicle' ? 'CAM-04' : 'CAM-03' });
            }
          }
        }
      } catch (e) {
        console.error("COCO-SSD detection error:", e);
      }
      if (!cancelled) {
        animationFrame = setTimeout(detectFrame, 180);
      }
    };

    if (activeStream) {
      loadModel();
    } else {
      if (onDetect) onDetect({ detected: false });
    }

    return () => {
      cancelled = true;
      if (animationFrame) clearTimeout(animationFrame);
      if (onDetect) onDetect({ detected: false });
      if (model) {
        try { model.dispose(); } catch(e) {}
      }
    };
  }, [activeStream, type, onDetect]);

  const colorHex = color === 'yellow' ? '#eab308' : '#ef4444';
  const bgClass = color === 'yellow' ? 'bg-yellow-950/30 border-yellow-800/60 text-yellow-400' : 'bg-red-950/30 border-red-800/60 text-red-400';

  return (
    <div className="flex-1 p-6 flex flex-col bg-slate-950 overflow-y-auto">
      <div className="flex justify-between items-center mb-6 border-b border-slate-800/80 pb-4">
        <h2 className="text-xl font-black text-white uppercase tracking-widest flex items-center gap-3">
          <Icon className="w-7 h-7" style={{ color: colorHex }}/> {title}
        </h2>
        <div className="flex items-center gap-3">
          <span className={`px-3 py-1 rounded text-xs font-mono font-bold border ${predictions.length > 0 ? 'bg-red-500/20 text-red-400 border-red-500/60 shadow-[0_0_10px_rgba(239,68,68,0.2)]' : 'bg-slate-900 text-slate-400 border-slate-800'}`}>
            {predictions.length > 0 ? `LIVE THREAT: ${predictions.length} ITEM(S)` : 'SENSOR NOMINAL'}
          </span>
        </div>
      </div>

      <div className="flex-1 flex gap-6 flex-col lg:flex-row min-h-[460px]">
        <div className="flex-1 relative rounded-xl overflow-hidden border border-slate-800 bg-slate-950 flex items-center justify-center min-h-[360px] shadow-2xl video-stable-container">
           {!activeStream && <div className="text-slate-500 font-mono text-sm">INITIALIZING SENSOR STREAM...</div>}
           
           <video 
             ref={videoRef} 
             autoPlay 
             playsInline 
             muted 
             className={`absolute inset-0 w-full h-full object-cover ${type === 'object' ? 'grayscale-[0.15]' : ''}`}
             style={{ transform: 'scaleX(-1)' }}
           />
           
           {predictions.map((p, idx) => (
             <div key={idx} className="absolute border-2 shadow-[0_0_15px_currentColor] z-20 pointer-events-none transition-all duration-150"
               style={{ 
                 borderColor: colorHex,
                 left: `${100 - p.x - p.w}%`, 
                 top: `${p.y}%`, 
                 width: `${p.w}%`, 
                 height: `${p.h}%` 
               }}>
               <div className="absolute -top-6 left-[-2px] px-2 py-0.5 text-xs font-bold font-mono text-slate-950 flex items-center gap-1 shadow-md" style={{ backgroundColor: colorHex }}>
                 <AlertTriangle className="w-3 h-3"/> {p.class.toUpperCase()} - {p.score}%
               </div>
             </div>
           ))}
           
           {type === 'vehicle' && predictions.length > 0 && (
             <div className="absolute top-[62%] left-[52%] w-32 h-14 border-2 border-blue-400 bg-blue-500/20 z-20 flex items-center justify-center pointer-events-none shadow-lg">
               <div className="absolute -bottom-6 left-0 text-[10px] text-blue-200 font-mono bg-slate-950 px-2 py-0.5 rounded border border-blue-800 whitespace-nowrap">ANPR TELEMETRY ACTIVE</div>
             </div>
           )}

           {type === 'object' && (
             <svg className="absolute inset-0 w-full h-full z-10 pointer-events-none" preserveAspectRatio="none">
               <polygon points="15,90 90,90 70,40 30,40" className="fill-yellow-500/10 stroke-yellow-500/50 stroke-[0.5]" />
             </svg>
           )}
        </div>

        <div className="w-full lg:w-96 flex flex-col gap-4">
           <div className={`border p-5 rounded-xl shadow-xl ${bgClass} backdrop-blur-sm`}>
             <h3 className="font-bold mb-4 flex items-center gap-2 border-b border-current pb-2 font-mono text-sm tracking-wide">
               <AlertTriangle className="w-4 h-4"/> {alertTitle}
             </h3>
             <div className="space-y-3.5 text-xs font-mono text-slate-300">
               {predictions.length > 0 ? (
                 <>
                   <div className="flex justify-between py-1 border-b border-slate-800/60"><span>Object Class:</span> <span className="text-white font-bold">{predictions[0].class.toUpperCase()}</span></div>
                   <div className="flex justify-between py-1 border-b border-slate-800/60"><span>Match Probability:</span> <span className="text-emerald-400 font-bold">{predictions[0].score}%</span></div>
                   <div className="flex justify-between py-1 border-b border-slate-800/60">
                     <span>Alarm Response:</span> 
                     <span className="text-red-400 font-bold">{alarmRemaining > 0 ? `SIREN ACTIVE (${alarmRemaining}s)` : 'ARMED'}</span>
                   </div>
                   {type === 'vehicle' ? (
                     <div className="mt-4 pt-3 border-t border-slate-800">
                       <span className="text-slate-400 block mb-1">OCR License Telemetry:</span> 
                       <div className="bg-slate-900 px-3 py-2 border border-slate-700 text-white rounded font-mono font-bold tracking-widest text-center text-sm shadow-inner">
                         KA 03 MX 4910
                       </div>
                     </div>
                   ) : (
                     <div className="mt-4 pt-3 border-t border-slate-800 space-y-2">
                       <div className="flex justify-between items-center">
                         <span className="text-slate-400">Stationary Hold Time:</span> 
                         <span className="text-red-400 font-bold text-sm bg-slate-900 px-2 py-0.5 rounded border border-red-900/60">00:08s</span>
                       </div>
                       <p className="text-[11px] text-slate-400 leading-relaxed bg-black/40 p-2 rounded border border-slate-800">
                         Rule Violation: Unattended object in security yellow grid. Siren sustained for {alarmDuration}s post-event.
                       </p>
                     </div>
                   )}
                 </>
               ) : (
                 <div className="text-center py-10 space-y-2">
                   <p className="text-slate-400 font-semibold">Sensor Active & Scanning Feed</p>
                   <p className="text-[11px] text-slate-500">Hold up a {type === 'vehicle' ? 'toy car or picture of vehicle' : 'backpack, bottle, or phone'} to trigger automatic siren.</p>
                 </div>
               )}
             </div>
           </div>
        </div>
      </div>
    </div>
  );
});

// --- MAIN CONTROLLER COMPONENT ---
export default function App() {
  const [stream, setStream] = useState(null);
  const [activeTab, setActiveTab] = useState('LIVE');
  
  // High-Precision Real-time Clock
  const [currentTimeStr, setCurrentTimeStr] = useState({ local: '', utc: '', date: '' });
  
  // Real-time authoritative incident events
  const [alerts, setAlerts] = useState([
    { 
      id: 1, 
      incidentId: 'INC-8091',
      time: '12:00:15', 
      timestamp: '2026-09-01 12:00:15.000',
      cam: 'CAM-01', 
      cameraName: 'CAM-01 [Main Perimeter RGB]',
      sector: 'Sector 4 - North Perimeter Grid [Zone A]',
      coordinates: '34.0522° N, 118.2437° W',
      classification: 'System Initialization',
      confidence: '100%',
      type: 'info', 
      severity: 'ADVISORY',
      status: 'LOGGED',
      msg: 'Tactical security mesh online. All outpost nodes nominal.', 
      image: 'https://images.unsplash.com/photo-1590159671607-b08e50b06b9b?auto=format&fit=crop&q=80&w=600' 
    }
  ]);
  
  // Siren Configuration States
  const [sirenManual, setSirenManual] = useState(false);
  const [autoSiren, setAutoSiren] = useState(true);
  const [autoSirenOnCriticalAlerts, setAutoSirenOnCriticalAlerts] = useState(true);
  const [alarmDuration, setAlarmDuration] = useState(5);
  const [alarmRemaining, setAlarmRemaining] = useState(0);
  const [sirenVolume, setSirenVolume] = useState(40);
  const [sirenTone, setSirenTone] = useState('wail');
  
  // Detection Tracking Ref for debounced authoritative logging
  const activeDetectionsRef = useRef(new Map());
  const lastLoggedRef = useRef(0);
  
  const [isCurrentlyDetecting, setIsCurrentlyDetecting] = useState(false);
  const [aiEnabled, setAiEnabled] = useState(true);
  const [zoneMode, setZoneMode] = useState('red');
  const [selectedAlertModal, setSelectedAlertModal] = useState(null);
  const [searchQuery, setSearchQuery] = useState('');
  
  const [topologyNodes, setTopologyNodes] = useState([
    { id: 1, name: 'Outpost Alpha-1 (Main RGB)', status: 'ONLINE', ping: '12ms', load: '32%', temp: '41°C', ip: '192.168.1.101', sensorType: '4K Sony Starvis RGB' },
    { id: 2, name: 'Outpost Alpha-2 (Night Vision)', status: 'ONLINE', ping: '17ms', load: '44%', temp: '45°C', ip: '192.168.1.102', sensorType: 'Low-Lux NIR Sensor' },
    { id: 3, name: 'Outpost Alpha-3 (IR Thermal)', status: 'OFFLINE', ping: '--', load: '0%', temp: '--', ip: '192.168.1.103', sensorType: 'FLIR Longwave IR' },
    { id: 4, name: 'Outpost Alpha-4 (ANPR Gate)', status: 'ONLINE', ping: '14ms', load: '26%', temp: '38°C', ip: '192.168.1.104', sensorType: 'High-Speed Global Shutter' },
  ]);

  // Live Military Clock ticker
  useEffect(() => {
    const updateClock = () => {
      const now = new Date();
      const local = now.toTimeString().split(' ')[0];
      const utc = now.toISOString().substring(11, 19) + ' UTC';
      const date = now.toISOString().substring(0, 10);
      setCurrentTimeStr({ local, utc, date });
    };
    updateClock();
    const timer = setInterval(updateClock, 1000);
    return () => clearInterval(timer);
  }, []);

  // Unlock AudioContext on first user interaction
  useEffect(() => {
    const unlockAudio = () => {
      sirenAudio.init();
      window.removeEventListener('click', unlockAudio);
      window.removeEventListener('keydown', unlockAudio);
      window.removeEventListener('touchstart', unlockAudio);
    };
    window.addEventListener('click', unlockAudio);
    window.addEventListener('keydown', unlockAudio);
    window.addEventListener('touchstart', unlockAudio);
    return () => {
      window.removeEventListener('click', unlockAudio);
      window.removeEventListener('keydown', unlockAudio);
      window.removeEventListener('touchstart', unlockAudio);
    };
  }, []);

  // Sync volume and tone to synthesizer
  useEffect(() => {
    sirenAudio.setVolume(sirenVolume / 100);
  }, [sirenVolume]);

  useEffect(() => {
    sirenAudio.setToneMode(sirenTone);
  }, [sirenTone]);

  // Master function to trigger alarm for N seconds
  const triggerAlarm = useCallback((seconds = alarmDuration) => {
    if (!autoSiren) return;
    sirenAudio.init();
    setAlarmRemaining(prev => Math.max(prev, seconds));
  }, [autoSiren, alarmDuration]);

  // Comprehensive incident logger with full Location, Camera ID, Timestamp & Details
  const logSecurityIncident = useCallback((eventData) => {
    const now = new Date();
    const timeStr = now.toTimeString().split(' ')[0];
    const fullIso = `${now.toISOString().replace('T', ' ').substring(0, 23)}`;
    const incId = `INC-${Math.floor(1000 + Math.random() * 9000)}`;

    const newAlert = {
      id: Date.now(),
      incidentId: incId,
      time: timeStr,
      timestamp: fullIso,
      cam: eventData.camId || 'CAM-01',
      cameraName: eventData.title || 'CAM-01 [Main Outpost]',
      sector: eventData.location || 'Sector 4 - North Perimeter Grid [Zone A]',
      coordinates: '34.0522° N, 118.2437° W',
      classification: eventData.classification || 'Unauthorized Entity',
      confidence: eventData.confidence || '96.5%',
      type: eventData.severity === 'CRITICAL' ? 'danger' : (eventData.severity === 'WARNING' ? 'warning' : 'info'),
      severity: eventData.severity || 'CRITICAL',
      status: 'ACTIVE_THREAT',
      msg: eventData.details || `${eventData.classification} detected in ${eventData.location}. Automated siren dispatched.`,
      image: eventData.image || `https://images.unsplash.com/photo-1616169992686-35327a13d782?auto=format&fit=crop&q=80&w=600&random=${Math.random()}`
    };

    setAlerts(prev => [newAlert, ...prev].slice(0, 100));
  }, []);

  // Handle incoming live detection events from camera subcomponents
  const handleDetectionUpdate = useCallback((event) => {
    const { detected, camId } = event;
    
    if (detected) {
      activeDetectionsRef.current.set(camId || 'default', true);
      setIsCurrentlyDetecting(true);
      
      if (autoSiren) {
        triggerAlarm(alarmDuration);
      }

      // Authoritative Log Debounce: log new authoritative event once every 8 seconds per active burst
      const nowMs = Date.now();
      if (nowMs - lastLoggedRef.current > 8000) {
        lastLoggedRef.current = nowMs;
        logSecurityIncident(event);
      }
    } else {
      activeDetectionsRef.current.delete(camId || 'default');
      if (activeDetectionsRef.current.size === 0) {
        setIsCurrentlyDetecting(false);
      }
    }
  }, [autoSiren, alarmDuration, triggerAlarm, logSecurityIncident]);

  // Countdown timer effect
  useEffect(() => {
    const interval = setInterval(() => {
      if (isCurrentlyDetecting && autoSiren) {
        setAlarmRemaining(alarmDuration);
      } else {
        setAlarmRemaining(prev => {
          if (prev <= 0.1) return 0;
          return Number((prev - 0.1).toFixed(1));
        });
      }
    }, 100);

    return () => clearInterval(interval);
  }, [isCurrentlyDetecting, autoSiren, alarmDuration]);

  // Manage Physical Siren Sound
  const isSirenActive = sirenManual || (autoSiren && alarmRemaining > 0);

  useEffect(() => {
    if (isSirenActive) {
      sirenAudio.start();
    } else {
      sirenAudio.stop();
    }
  }, [isSirenActive]);

  // Initialize Continuous Live Webcam
  useEffect(() => {
    let currentStream = null;
    const initCamera = async () => {
      try {
        const mediaStream = await navigator.mediaDevices.getUserMedia({ video: true, audio: false });
        currentStream = mediaStream;
        setStream(mediaStream);
      } catch (err) {
        console.error("Error accessing webcam:", err);
      }
    };
    initCamera();

    return () => {
      if (currentStream) {
        currentStream.getTracks().forEach(track => track.stop());
      }
    };
  }, []);

  // Simulated Tactical Telemetry Alerts (with full location, camera, and timestamp details)
  useEffect(() => {
    const timer = setInterval(() => {
      if (Math.random() > 0.7) {
        const camList = [
          { cam: 'CAM-01', name: 'CAM-01 [Main Perimeter RGB]', loc: 'Sector 1 - North Gate Grid A-1', class: 'Perimeter Boundary Scaled', details: 'Unidentified subject climbing external perimeter fence line.' },
          { cam: 'CAM-02', name: 'CAM-02 [Zero-Lux Night Vision]', loc: 'Sector 2 - East Perimeter Trench', class: 'Infrared Motion Breach', details: 'Directional tripwire breached (Inbound movement vector).' },
          { cam: 'CAM-03', name: 'CAM-03 [Depot Vault Sensor]', loc: 'Sector 3 - Secure Storage Depot', class: 'Optical Sensor Tampering', details: 'Sensor blinding / high-intensity laser interference detected.' },
          { cam: 'CAM-04', name: 'CAM-04 [ANPR Gate Checkpoint]', loc: 'Sector 4 - South Entry Gate', class: 'Unregistered Vehicle Incursion', details: 'Vehicle passed automated barrier without valid RFID clearance.' }
        ];

        const item = camList[Math.floor(Math.random() * camList.length)];
        const isCritical = Math.random() > 0.35;

        logSecurityIncident({
          camId: item.cam,
          title: item.name,
          location: item.loc,
          classification: item.class,
          confidence: `${Math.floor(Math.random() * 10) + 90}%`,
          severity: isCritical ? 'CRITICAL' : 'WARNING',
          details: item.details
        });

        if (isCritical && autoSirenOnCriticalAlerts && autoSiren) {
          triggerAlarm(alarmDuration);
        }
      }
    }, 9000);
    return () => clearInterval(timer);
  }, [autoSirenOnCriticalAlerts, autoSiren, alarmDuration, triggerAlarm, logSecurityIncident]);

  // Export Incident Log feature
  const exportLogData = () => {
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(alerts, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute("href", dataStr);
    downloadAnchor.setAttribute("download", `sentinedge_telemetry_log_${Date.now()}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  const handleTabChange = useCallback((newTab) => {
    setIsCurrentlyDetecting(false);
    activeDetectionsRef.current.clear();
    setActiveTab(newTab);
  }, []);

  const filteredAlerts = alerts.filter(a => {
    if (!searchQuery) return true;
    const query = searchQuery.toLowerCase();
    return a.cam.toLowerCase().includes(query) || 
           a.sector.toLowerCase().includes(query) || 
           a.msg.toLowerCase().includes(query) ||
           a.classification.toLowerCase().includes(query);
  });

  return (
    <div className={`min-h-screen bg-slate-950 text-slate-200 font-sans flex flex-col selection:bg-emerald-500/30 ${isSirenActive ? 'border-2 border-red-600/90 shadow-[inset_0_0_100px_rgba(220,38,38,0.25)]' : 'border border-slate-900'}`}>
      
      {/* 1. TOP TACTICAL TELEMETRY STATUS BAR */}
      <div className="bg-black/90 border-b border-slate-800/80 px-4 py-1.5 flex justify-between items-center text-[11px] font-mono text-slate-400 select-none">
        <div className="flex items-center gap-4">
          <span className="flex items-center gap-1.5 text-white font-bold">
            <Radio className={`w-3.5 h-3.5 ${isSirenActive ? 'text-red-500 animate-pulse' : 'text-emerald-400'}`} />
            SENTINEDGE CORE 2.4
          </span>
          <span className="text-slate-600">|</span>
          <span>LOCAL: <strong className="text-slate-200">{currentTimeStr.local || '--:--:--'}</strong></span>
          <span className="text-slate-600">|</span>
          <span>UTC: <strong className="text-slate-200">{currentTimeStr.utc || '--:--:--'}</strong></span>
          <span className="text-slate-600">|</span>
          <span>DATE: <strong className="text-slate-200">{currentTimeStr.date || '----/--/--'}</strong></span>
        </div>

        <div className="flex items-center gap-4">
          <div className="flex items-center gap-1.5">
            <Cpu className="w-3 h-3 text-cyan-400"/>
            <span>NPU: <strong className="text-slate-200">16.4 FPS (WebGL)</strong></span>
          </div>
          <span className="text-slate-600">|</span>
          <div className="flex items-center gap-1.5">
            <Network className="w-3 h-3 text-emerald-400"/>
            <span>BANDWIDTH: <strong className="text-slate-200">4.8 Mbps</strong></span>
          </div>
          <span className="text-slate-600">|</span>
          <div className="flex items-center gap-1.5">
            <span className={`w-2 h-2 rounded-full ${isSirenActive ? 'bg-red-500 shadow-[0_0_8px_#ef4444]' : 'bg-emerald-500 shadow-[0_0_8px_#10b981]'}`}></span>
            <span className={`font-bold ${isSirenActive ? 'text-red-400' : 'text-emerald-400'}`}>
              {isSirenActive ? 'DEFCON 1 (CRITICAL THREAT)' : 'DEFCON 4 (NOMINAL)'}
            </span>
          </div>
        </div>
      </div>

      {/* 2. GLOBAL MAIN COMMAND HEADER */}
      <header className={`border-b transition-colors ${isSirenActive ? 'border-red-600/80 bg-red-950/40' : 'border-slate-800 bg-slate-900/90'} px-6 py-3 flex items-center justify-between shadow-lg z-40 backdrop-blur-md`}>
        <div className="flex items-center gap-3">
          <div className="relative">
            <ShieldAlert className={`w-8 h-8 ${isSirenActive ? 'text-red-500 drop-shadow-[0_0_12px_#ef4444]' : 'text-red-500 drop-shadow-[0_0_8px_rgba(239,68,68,0.6)]'}`} />
            {isSirenActive && <div className="absolute inset-0 rounded-full bg-red-500/30 animate-ping"></div>}
          </div>
          <div>
            <h1 className="text-lg font-black tracking-widest text-white uppercase flex items-center gap-2 font-mono">
              SentinEdge-AI
              {isSirenActive ? (
                <span className="text-[11px] bg-red-600 text-white font-mono px-2 py-0.5 rounded font-bold shadow-[0_0_12px_#ef4444] flex items-center gap-1">
                  <AlertTriangle className="w-3 h-3"/> SIREN ACTIVE {alarmRemaining > 0 ? `(${alarmRemaining}s)` : ''}
                </span>
              ) : (
                <span className="text-[10px] bg-emerald-950/80 text-emerald-400 border border-emerald-500/40 font-mono px-1.5 py-0.5 rounded">
                  ARMED & MONITORING
                </span>
              )}
            </h1>
            <p className="text-[10px] text-emerald-500 font-mono tracking-widest">TACTICAL PERIMETER DEFENSE COMMAND</p>
          </div>
        </div>

        {/* COMPACT DYNAMIC TAB NAVIGATION */}
        <div className="flex bg-slate-950 p-1 rounded-lg border border-slate-800 max-w-4xl overflow-x-auto custom-scrollbar">
          <button onClick={() => handleTabChange('LIVE')} className={`flex whitespace-nowrap items-center gap-1.5 px-3 py-1.5 rounded font-bold text-xs transition-colors ${activeTab === 'LIVE' ? 'bg-slate-800 text-white shadow-sm' : 'text-slate-400 hover:text-slate-200'}`}><Activity className="w-3.5 h-3.5"/> LIVE OUTPOSTS</button>
          <div className="w-px bg-slate-800 mx-1"></div>
          <button onClick={() => handleTabChange('VEHICLES')} className={`flex whitespace-nowrap items-center gap-1.5 px-3 py-1.5 rounded font-bold text-xs transition-colors ${activeTab === 'VEHICLES' ? 'bg-yellow-900/40 text-yellow-400 border border-yellow-800/60' : 'text-slate-400 hover:text-yellow-400'}`}><Car className="w-3.5 h-3.5"/> ANPR VEHICLES</button>
          <button onClick={() => handleTabChange('OBJECTS')} className={`flex whitespace-nowrap items-center gap-1.5 px-3 py-1.5 rounded font-bold text-xs transition-colors ${activeTab === 'OBJECTS' ? 'bg-red-900/40 text-red-400 border border-red-800/60' : 'text-slate-400 hover:text-red-400'}`}><Package className="w-3.5 h-3.5"/> OBJECT SECURITY</button>
          <div className="w-px bg-slate-800 mx-1"></div>
          <button onClick={() => handleTabChange('GALLERY')} className={`flex whitespace-nowrap items-center gap-1.5 px-3 py-1.5 rounded font-bold text-xs transition-colors ${activeTab === 'GALLERY' ? 'bg-slate-800 text-white shadow-sm' : 'text-slate-400 hover:text-slate-200'}`}><ImageIcon className="w-3.5 h-3.5"/> INCIDENT LOG ({alerts.length})</button>
          <button onClick={() => handleTabChange('TOPOLOGY')} className={`flex whitespace-nowrap items-center gap-1.5 px-3 py-1.5 rounded font-bold text-xs transition-colors ${activeTab === 'TOPOLOGY' ? 'bg-slate-800 text-white shadow-sm' : 'text-slate-400 hover:text-slate-200'}`}><Server className="w-3.5 h-3.5"/> NODE TOPOLOGY</button>
          <button onClick={() => handleTabChange('SETTINGS')} className={`flex whitespace-nowrap items-center gap-1.5 px-3 py-1.5 rounded font-bold text-xs transition-colors ${activeTab === 'SETTINGS' ? 'bg-slate-800 text-white shadow-sm' : 'text-slate-400 hover:text-slate-200'}`}><Settings className="w-3.5 h-3.5"/> SYSTEM SETTINGS</button>
        </div>

        {/* HEADER CONTROLS */}
        <div className="flex items-center gap-3">
          <button 
            onClick={() => setAutoSiren(!autoSiren)} 
            title="Auto-trigger siren audio whenever human/vehicle/object activity is detected"
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded font-mono text-xs border transition-all ${autoSiren ? 'bg-emerald-950/50 border-emerald-500/70 text-emerald-400' : 'bg-slate-800 border-slate-700 text-slate-400 hover:bg-slate-700'}`}>
            {autoSiren ? <Bell className="w-3.5 h-3.5 text-emerald-400 animate-pulse"/> : <BellOff className="w-3.5 h-3.5"/>}
            <span>AUTO SIREN ({alarmDuration}s): {autoSiren ? 'ON' : 'MUTED'}</span>
          </button>

          <button 
            onClick={() => {
              if (isSirenActive) {
                setSirenManual(false);
                setAlarmRemaining(0);
              } else {
                setSirenManual(true);
              }
            }} 
            className={`flex items-center gap-2 px-4 py-1.5 rounded font-black tracking-widest text-xs border transition-all ${isSirenActive ? 'bg-red-600 border-red-500 text-white shadow-[0_0_20px_#ef4444]' : 'bg-red-950/30 border-red-900/50 text-red-500 hover:bg-red-900/50'}`}>
            {isSirenActive ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />} 
            <span>{isSirenActive ? `SIREN ACTIVE ${alarmRemaining > 0 ? `(${alarmRemaining}s)` : ''}` : 'MANUAL SIREN'}</span>
          </button>
        </div>
      </header>

      {/* 3. MAIN CONTENT WORKSPACE */}
      <main className="flex-1 flex overflow-hidden">
        {activeTab === 'LIVE' && (
          <>
            <div className="flex-1 flex flex-col bg-slate-950">
              {/* Tactical Action Toolbar */}
              <div className="bg-slate-900/80 p-2.5 border-b border-slate-800/80 flex gap-3 px-6 items-center flex-wrap backdrop-blur-sm">
                <span className="text-[11px] font-mono text-slate-400 font-bold">DETECTION TOOLS:</span>
                <button onClick={() => setAiEnabled(!aiEnabled)} className={`flex items-center gap-1.5 px-3 py-1 rounded font-mono text-xs border transition-colors ${aiEnabled ? 'bg-emerald-950/60 border-emerald-500/70 text-emerald-400' : 'bg-slate-800 border-slate-700 text-slate-400'}`}>
                  <Zap className="w-3.5 h-3.5" /> AI OVERLAYS: {aiEnabled ? 'ON' : 'OFF'}
                </button>
                <div className="h-4 w-px bg-slate-800 mx-1"></div>
                <span className="text-[11px] font-mono text-slate-400 font-bold">SECURITY SECTOR ZONES:</span>
                <button onClick={() => setZoneMode('red')} className={`px-3 py-1 rounded font-mono text-xs font-bold border transition-colors ${zoneMode === 'red' ? 'bg-red-950/60 border-red-500 text-red-400' : 'bg-slate-800/80 border-slate-700 text-slate-400 hover:bg-slate-700'}`}>🔴 LETHAL BOUNDARY</button>
                <button onClick={() => setZoneMode('yellow')} className={`px-3 py-1 rounded font-mono text-xs font-bold border transition-colors ${zoneMode === 'yellow' ? 'bg-yellow-950/60 border-yellow-500 text-yellow-400' : 'bg-slate-800/80 border-slate-700 text-slate-400 hover:bg-slate-700'}`}>🟡 WARNING SECTOR</button>
                <button onClick={() => setZoneMode('tripwire')} className={`px-3 py-1 rounded font-mono text-xs font-bold border transition-colors ${zoneMode === 'tripwire' ? 'bg-blue-950/60 border-blue-500 text-blue-400' : 'bg-slate-800/80 border-slate-700 text-slate-400 hover:bg-slate-700'}`}>🟦 VIRTUAL TRIPWIRE</button>
                
                {alarmRemaining > 0 && (
                  <div className="ml-auto flex items-center gap-2 bg-red-950/90 border border-red-500 text-red-400 px-3 py-1 rounded font-mono text-xs font-bold shadow-lg">
                    <AlertTriangle className="w-3.5 h-3.5 animate-pulse text-red-500"/> SIREN COUNTDOWN: {alarmRemaining}s
                  </div>
                )}
              </div>

              {/* 4-Camera Tactical Grid */}
              <section className="flex-1 p-4 grid grid-cols-1 md:grid-cols-2 gap-4 overflow-y-auto">
                <CameraView 
                  activeStream={stream} 
                  camId="CAM-01"
                  locationName="North Perimeter Alpha"
                  title="CAM-01: MAIN OUTPOST (RGB HD)" 
                  filterClass="" 
                  showOverlays={true} 
                  onDetect={handleDetectionUpdate} 
                  zoneMode={zoneMode}
                  aiEnabled={aiEnabled}
                />
                <CameraView 
                  activeStream={stream} 
                  camId="CAM-02"
                  locationName="East Perimeter Trench"
                  title="CAM-02: ZERO-LUX (NIGHT VISION)" 
                  filterClass="sepia-[.4] hue-rotate-[75deg] saturate-200 contrast-150 brightness-85" 
                  showOverlays={false} 
                  onDetect={handleDetectionUpdate}
                  zoneMode={zoneMode}
                  aiEnabled={aiEnabled}
                />
                <CameraView 
                  activeStream={stream} 
                  camId="CAM-03"
                  locationName="Secure Storage Vault"
                  title="CAM-03: DE-FOGGING OPTICAL" 
                  filterClass="contrast-[1.4] grayscale-[0.25] brightness-[1.05]" 
                  showOverlays={false} 
                  onDetect={handleDetectionUpdate}
                  zoneMode={zoneMode}
                  aiEnabled={aiEnabled}
                />
                <CameraView 
                  activeStream={stream} 
                  camId="CAM-04"
                  locationName="South Gate Barrier"
                  title="CAM-04: THERMAL (IR SENSOR)" 
                  filterClass="invert-[.9] contrast-[1.6] grayscale" 
                  showOverlays={false} 
                  onDetect={handleDetectionUpdate}
                  zoneMode={zoneMode}
                  aiEnabled={aiEnabled}
                />
              </section>
            </div>

            {/* REAL-TIME STRUCTURED INCIDENT EVENT STREAM */}
            <aside className="w-96 border-l border-slate-800/80 bg-slate-950 flex flex-col z-30 shadow-2xl">
              <div className="p-3.5 border-b border-slate-800 bg-slate-900/90 flex justify-between items-center">
                <h2 className="font-bold text-slate-200 flex items-center gap-2 text-xs font-mono tracking-widest uppercase">
                  <MapPin className="w-4 h-4 text-emerald-400"/> INCIDENT TELEMETRY STREAM
                </h2>
                <div className="flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse"></span>
                  <span className="text-[10px] font-mono text-slate-400">{alerts.length} LOGS</span>
                </div>
              </div>

              <div className="p-2 border-b border-slate-800 bg-slate-950/90 flex gap-2">
                <div className="relative flex-1">
                  <Search className="w-3.5 h-3.5 text-slate-500 absolute left-2.5 top-2.5"/>
                  <input 
                    type="text" 
                    placeholder="Filter by Cam / Location / Threat..." 
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-800 rounded pl-8 pr-2 py-1.5 text-xs font-mono text-slate-300 focus:outline-none focus:border-slate-600"
                  />
                </div>
                <button 
                  onClick={exportLogData}
                  title="Download telemetry incident records"
                  className="bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 px-2 py-1 rounded text-xs">
                  <Download className="w-3.5 h-3.5"/>
                </button>
              </div>

              {/* Event Log List with Detailed Camera, Time & Location */}
              <div className="flex-1 overflow-y-auto p-3 space-y-2.5 font-mono text-xs leading-tight custom-scrollbar">
                {filteredAlerts.map((alert) => (
                  <div 
                    key={alert.id} 
                    onClick={() => setSelectedAlertModal(alert)}
                    className={`p-3 rounded-lg border-l-4 cursor-pointer transition-all hover:bg-slate-900/90 ${
                      alert.severity === 'CRITICAL' 
                        ? 'bg-red-950/20 border-red-500 text-red-200 border border-r-slate-800 border-y-slate-800' 
                        : (alert.severity === 'WARNING' 
                            ? 'bg-yellow-950/20 border-yellow-500 text-yellow-200 border border-r-slate-800 border-y-slate-800' 
                            : 'bg-slate-900/60 border-slate-600 text-slate-300 border border-r-slate-800 border-y-slate-800')
                    }`}>
                    <div className="flex justify-between items-center mb-1.5">
                      <div className="flex items-center gap-1.5">
                        <span className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${alert.severity === 'CRITICAL' ? 'bg-red-600 text-white' : (alert.severity === 'WARNING' ? 'bg-yellow-600 text-black' : 'bg-slate-800 text-slate-300')}`}>
                          {alert.cam}
                        </span>
                        <span className="text-[10px] text-slate-400 font-bold">{alert.incidentId}</span>
                      </div>
                      <span className="text-[10px] text-slate-400 flex items-center gap-1">
                        <Clock className="w-3 h-3 text-slate-500"/> {alert.time}
                      </span>
                    </div>

                    <div className="text-[11px] font-semibold text-white mb-1 flex items-center gap-1">
                      <MapPin className="w-3 h-3 text-emerald-400 shrink-0"/> {alert.sector}
                    </div>

                    <p className="text-[11px] text-slate-300 leading-snug">{alert.msg}</p>
                  </div>
                ))}
              </div>
            </aside>
          </>
        )}
        
        {/* TAB: VEHICLES */}
        {activeTab === 'VEHICLES' && (
           <LiveDetectionView 
             title="Automated Number Plate & Vehicle Recognition" 
             icon={Car} 
             type="vehicle" 
             activeStream={stream} 
             color="yellow" 
             alertTitle="VEHICULAR TELEMETRY SCANNER"
             onDetect={handleDetectionUpdate}
             alarmRemaining={alarmRemaining}
             alarmDuration={alarmDuration}
           />
        )}

        {/* TAB: OBJECTS */}
        {activeTab === 'OBJECTS' && (
           <LiveDetectionView 
             title="Tampering & Unattended Threat Object Scanner" 
             icon={Package} 
             type="object" 
             activeStream={stream} 
             color="red" 
             alertTitle="CRITICAL OBJECT PERIMETER ALARM"
             onDetect={handleDetectionUpdate}
             alarmRemaining={alarmRemaining}
             alarmDuration={alarmDuration}
           />
        )}
        
        {/* TAB: GALLERY */}
        {activeTab === 'GALLERY' && (
          <div className="flex-1 p-6 overflow-y-auto bg-slate-950">
            <div className="flex justify-between items-center mb-6 border-b border-slate-800 pb-4">
              <div>
                <h2 className="text-xl font-black text-white uppercase tracking-widest flex items-center gap-2 font-mono">
                  <ImageIcon className="text-emerald-400"/> Forensic Incident Gallery & Logbook
                </h2>
                <p className="text-xs text-slate-400 mt-1 font-mono">Real-time captured threat frames with camera, sector and time stamps</p>
              </div>
              <div className="flex gap-2">
                <button onClick={exportLogData} className="px-4 py-2 text-xs font-mono font-bold rounded bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 flex items-center gap-1.5">
                  <Download className="w-3.5 h-3.5"/> EXPORT JSON
                </button>
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {alerts.map(alert => (
                <div 
                  key={alert.id} 
                  onClick={() => setSelectedAlertModal(alert)}
                  className={`rounded-xl overflow-hidden border-2 bg-slate-900/90 flex flex-col cursor-pointer transition-all hover:scale-[1.01] hover:border-slate-600 ${alert.severity === 'CRITICAL' ? 'border-red-900/50 shadow-lg' : 'border-slate-800'}`}>
                  <div className="h-48 relative overflow-hidden group bg-black">
                    <img src={alert.image} alt="Incident" className="w-full h-full object-cover opacity-80 group-hover:scale-105 transition-transform duration-300" />
                    <div className="absolute top-2 left-2 bg-black/80 px-2 py-1 rounded text-xs font-mono text-white flex items-center gap-1 border border-slate-700">
                      <Video className="w-3 h-3 text-emerald-400"/> {alert.cam}
                    </div>
                    {alert.severity === 'CRITICAL' && (
                      <div className="absolute top-2 right-2 bg-red-600 px-2 py-0.5 rounded text-[10px] font-bold text-white flex items-center gap-1 animate-pulse font-mono">
                        <AlertTriangle className="w-3 h-3"/> CRITICAL
                      </div>
                    )}
                    <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity text-white text-xs font-mono font-bold gap-1">
                      <Eye className="w-4 h-4 text-emerald-400"/> INSPECT TELEMETRY
                    </div>
                  </div>
                  <div className="p-4 flex-1 flex flex-col space-y-2">
                    <div className="flex justify-between items-center text-slate-400 text-xs font-mono">
                      <span className="flex items-center gap-1"><Clock className="w-3 h-3"/> {alert.time}</span>
                      <span className="text-slate-500">{alert.incidentId}</span>
                    </div>
                    <div className="text-xs font-bold text-white font-mono flex items-center gap-1">
                      <MapPin className="w-3.5 h-3.5 text-emerald-400 shrink-0"/> {alert.sector}
                    </div>
                    <p className={`font-medium text-xs flex-1 ${alert.severity === 'CRITICAL' ? 'text-red-400' : 'text-slate-300'}`}>{alert.msg}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* TAB: TOPOLOGY */}
        {activeTab === 'TOPOLOGY' && (
          <div className="flex-1 p-6 overflow-y-auto bg-slate-950 text-slate-300">
            <div className="flex justify-between items-center mb-6 border-b border-slate-800 pb-4">
              <div>
                <h2 className="text-xl font-black text-white uppercase tracking-widest flex items-center gap-2 font-mono">
                  <Server className="text-purple-400"/> Outpost Node Topology & Health
                </h2>
                <p className="text-xs text-slate-400 mt-1 font-mono">Mesh network node operational status and latency telemetry</p>
              </div>
              <span className="text-xs font-mono text-emerald-400 bg-emerald-950/40 border border-emerald-500/50 px-2.5 py-1 rounded">
                4/4 NODES MESH DISCOVERED
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
               {topologyNodes.map(node => (
                 <div key={node.id} className="border border-slate-800 bg-slate-900/90 rounded-xl p-5 hover:border-slate-700 transition-all flex flex-col justify-between shadow-xl">
                   <div>
                     <div className="flex justify-between items-center mb-3">
                       <h3 className="font-bold text-white text-sm font-mono">{node.name}</h3>
                       <span className={`px-2 py-0.5 rounded text-[10px] font-bold font-mono border ${node.status === 'OFFLINE' ? 'bg-red-500/20 text-red-400 border-red-500/50' : 'bg-emerald-500/20 text-emerald-400 border-emerald-500/50'}`}>
                         {node.status}
                       </span>
                     </div>
                     <div className="space-y-2 text-xs font-mono text-slate-400 bg-slate-950/80 p-3 rounded-lg border border-slate-800/80">
                       <div className="flex justify-between"><span>Sensor:</span> <span className="text-slate-200 text-[11px]">{node.sensorType}</span></div>
                       <div className="flex justify-between"><span>IP:</span> <span className="text-slate-200">{node.ip}</span></div>
                       <div className="flex justify-between"><span>Latency:</span> <span className="text-emerald-400 font-bold">{node.ping}</span></div>
                       <div className="flex justify-between"><span>Load:</span> <span className="text-slate-200">{node.load}</span></div>
                       <div className="flex justify-between"><span>Temp:</span> <span className="text-slate-200">{node.temp}</span></div>
                     </div>
                   </div>

                   <div className="mt-4 pt-3 border-t border-slate-800 flex gap-2">
                     <button 
                       onClick={() => {
                         setTopologyNodes(prev => prev.map(n => n.id === node.id ? { ...n, status: n.status === 'ONLINE' ? 'OFFLINE' : 'ONLINE' } : n));
                       }}
                       className="flex-1 py-1.5 px-2 rounded text-xs font-mono font-bold bg-slate-800 text-slate-300 border border-slate-700 hover:bg-slate-700">
                       {node.status === 'ONLINE' ? 'DISABLE' : 'ENABLE'}
                     </button>
                     <button 
                       onClick={() => triggerAlarm(3)}
                       className="py-1.5 px-3 rounded text-xs font-mono bg-red-950/30 text-red-400 border border-red-900/60 hover:bg-red-900/50">
                       TEST ALARM
                     </button>
                   </div>
                 </div>
               ))}
            </div>
          </div>
        )}

        {/* TAB: SETTINGS */}
        {activeTab === 'SETTINGS' && (
          <div className="flex-1 p-6 overflow-y-auto bg-slate-950 text-slate-200">
            <div className="flex justify-between items-center mb-6 border-b border-slate-800 pb-4">
              <div>
                <h2 className="text-xl font-black text-white uppercase tracking-widest flex items-center gap-2 font-mono">
                  <Settings className="text-emerald-400"/> Tactical System & Siren Configuration
                </h2>
                <p className="text-xs text-slate-400 mt-1 font-mono">Configure siren response timing, audio frequency, and automated defense rules</p>
              </div>
              <span className="text-xs font-mono text-emerald-400 flex items-center gap-1.5 bg-emerald-950/40 border border-emerald-500/50 px-3 py-1 rounded">
                <CheckCircle2 className="w-4 h-4"/> REAL-TIME CONFIG SYNCED
              </span>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 max-w-5xl">
              {/* Siren Parameters */}
              <div className="border border-slate-800 bg-slate-900/80 rounded-xl p-6 shadow-xl space-y-6">
                <h3 className="text-base font-bold text-white flex items-center gap-2 border-b border-slate-800 pb-3 font-mono">
                  <Volume2 className="text-red-500"/> Siren & Alarm Parameters
                </h3>

                <div>
                  <div className="flex justify-between mb-2">
                    <label className="text-xs font-bold text-slate-300 font-mono">SIREN HOLD DURATION AFTER ACTIVITY:</label>
                    <span className="text-xs font-bold font-mono text-red-400 bg-red-950/60 px-2 py-0.5 rounded border border-red-900">{alarmDuration} SECONDS</span>
                  </div>
                  <input 
                    type="range" 
                    min="1" 
                    max="30" 
                    value={alarmDuration} 
                    onChange={(e) => setAlarmDuration(Number(e.target.value))}
                    className="w-full h-2 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-red-500" 
                  />
                  <p className="text-[11px] text-slate-400 mt-1 font-mono">Upon intrusion detection, siren wails for at least {alarmDuration}s even after subject exits the frame.</p>
                </div>

                <div>
                  <div className="flex justify-between mb-2">
                    <label className="text-xs font-bold text-slate-300 font-mono">SPEAKER OUTPUT VOLUME:</label>
                    <span className="text-xs font-bold font-mono text-emerald-400 bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-900">{sirenVolume}%</span>
                  </div>
                  <input 
                    type="range" 
                    min="5" 
                    max="100" 
                    value={sirenVolume} 
                    onChange={(e) => setSirenVolume(Number(e.target.value))}
                    className="w-full h-2 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-emerald-500" 
                  />
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-300 font-mono block mb-2">SIREN AUDIO SYNTHESIS TONE:</label>
                  <div className="grid grid-cols-3 gap-3">
                    {[
                      { id: 'wail', label: 'Tactical Wail (2 Hz)' },
                      { id: 'yelp', label: 'Fast Yelp (4.5 Hz)' },
                      { id: 'pulse', label: 'Pulse Alarm (6 Hz)' }
                    ].map(t => (
                      <button
                        key={t.id}
                        onClick={() => setSirenTone(t.id)}
                        className={`py-2 px-3 rounded-lg text-xs font-mono font-bold border transition-all ${sirenTone === t.id ? 'bg-red-600 text-white border-red-500 shadow-[0_0_12px_#ef4444]' : 'bg-slate-800 text-slate-400 border-slate-700 hover:bg-slate-700'}`}>
                        {t.label}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="pt-2 flex gap-3">
                  <button 
                    onClick={() => triggerAlarm(3)}
                    className="flex-1 bg-red-900/40 hover:bg-red-800/60 border border-red-500 text-white font-mono font-bold text-xs py-2.5 px-4 rounded-lg flex items-center justify-center gap-2">
                    <Play className="w-4 h-4 text-red-400"/> PREVIEW SIREN (3s)
                  </button>
                  <button 
                    onClick={() => {
                      setSirenManual(false);
                      setAlarmRemaining(0);
                    }}
                    className="bg-slate-800 hover:bg-slate-700 text-slate-300 font-mono text-xs py-2.5 px-4 rounded-lg border border-slate-700">
                    SILENCE ALL
                  </button>
                </div>
              </div>

              {/* Automation Rules */}
              <div className="border border-slate-800 bg-slate-900/80 rounded-xl p-6 shadow-xl space-y-5">
                <h3 className="text-base font-bold text-white flex items-center gap-2 border-b border-slate-800 pb-3 font-mono">
                  <Zap className="text-yellow-500"/> Automated Trigger Protocols
                </h3>

                <div className="flex items-center justify-between p-3.5 rounded-lg bg-slate-950/70 border border-slate-800">
                  <div>
                    <h4 className="font-bold text-xs font-mono text-slate-200">Auto-Alarm on AI Vision Detection</h4>
                    <p className="text-[11px] text-slate-400 mt-0.5">Trigger {alarmDuration}s siren whenever Human/Face, Vehicle, or Item is seen.</p>
                  </div>
                  <button 
                    onClick={() => setAutoSiren(!autoSiren)}
                    className={`px-3 py-1 rounded font-mono text-xs font-bold border ${autoSiren ? 'bg-emerald-600 text-white border-emerald-500' : 'bg-slate-800 text-slate-400 border-slate-700'}`}>
                    {autoSiren ? 'ENABLED' : 'MUTED'}
                  </button>
                </div>

                <div className="flex items-center justify-between p-3.5 rounded-lg bg-slate-950/70 border border-slate-800">
                  <div>
                    <h4 className="font-bold text-xs font-mono text-slate-200">Auto-Alarm on Critical Telemetry Events</h4>
                    <p className="text-[11px] text-slate-400 mt-0.5">Sound siren for {alarmDuration}s on incoming critical threat logs.</p>
                  </div>
                  <button 
                    onClick={() => setAutoSirenOnCriticalAlerts(!autoSirenOnCriticalAlerts)}
                    className={`px-3 py-1 rounded font-mono text-xs font-bold border ${autoSirenOnCriticalAlerts ? 'bg-emerald-600 text-white border-emerald-500' : 'bg-slate-800 text-slate-400 border-slate-700'}`}>
                    {autoSirenOnCriticalAlerts ? 'ENABLED' : 'DISABLED'}
                  </button>
                </div>

                <div className="flex items-center justify-between p-3.5 rounded-lg bg-slate-950/70 border border-slate-800">
                  <div>
                    <h4 className="font-bold text-xs font-mono text-slate-200">Real-Time Neural Inference Models</h4>
                    <p className="text-[11px] text-slate-400 mt-0.5">BlazeFace and COCO-SSD models active on camera streams.</p>
                  </div>
                  <button 
                    onClick={() => setAiEnabled(!aiEnabled)}
                    className={`px-3 py-1 rounded font-mono text-xs font-bold border ${aiEnabled ? 'bg-blue-600 text-white border-blue-500' : 'bg-slate-800 text-slate-400 border-slate-700'}`}>
                    {aiEnabled ? 'ACTIVE' : 'OFFLINE'}
                  </button>
                </div>

                <div className="pt-2">
                  <button 
                    onClick={() => triggerAlarm(10)}
                    className="w-full bg-red-600 hover:bg-red-700 text-white font-mono font-bold text-xs py-3 px-4 rounded-lg flex items-center justify-center gap-2 shadow-lg">
                    <AlertTriangle className="w-4 h-4"/> DISPATCH EMERGENCY HIGH-PRIORITY ALARM (10s)
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </main>

      {/* 4. FORENSIC INCIDENT DETAIL MODAL */}
      {selectedAlertModal && (
        <div className="fixed inset-0 bg-black/85 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-xl max-w-xl w-full overflow-hidden shadow-2xl">
            <div className="p-4 bg-slate-950 border-b border-slate-800 flex justify-between items-center">
              <h3 className="font-bold text-white font-mono text-sm flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-red-500"/> INCIDENT FORENSIC RECORD - {selectedAlertModal.incidentId}
              </h3>
              <button 
                onClick={() => setSelectedAlertModal(null)}
                className="text-slate-400 hover:text-white p-1 rounded">
                <X className="w-5 h-5"/>
              </button>
            </div>
            <div className="p-5 space-y-4 font-mono">
              <div className="h-60 rounded-lg overflow-hidden border border-slate-800 relative bg-black">
                <img src={selectedAlertModal.image} alt="Incident" className="w-full h-full object-cover" />
                <div className="absolute top-2 left-2 bg-black/80 px-2 py-1 rounded text-xs text-white border border-slate-700">
                  CAMERA: {selectedAlertModal.cam}
                </div>
                <div className="absolute top-2 right-2 bg-red-600 text-white px-2 py-0.5 rounded text-xs font-bold">
                  {selectedAlertModal.severity}
                </div>
              </div>

              <div className="p-3.5 bg-slate-950 rounded-lg border border-slate-800 text-xs space-y-2">
                <div className="flex justify-between"><span className="text-slate-400">Timestamp:</span> <span className="text-white font-bold">{selectedAlertModal.timestamp}</span></div>
                <div className="flex justify-between"><span className="text-slate-400">Sensor Device:</span> <span className="text-white">{selectedAlertModal.cameraName || selectedAlertModal.cam}</span></div>
                <div className="flex justify-between"><span className="text-slate-400">Sector Location:</span> <span className="text-emerald-400 font-bold">{selectedAlertModal.sector}</span></div>
                <div className="flex justify-between"><span className="text-slate-400">Geo-Coordinates:</span> <span className="text-slate-200">{selectedAlertModal.coordinates}</span></div>
                <div className="flex justify-between"><span className="text-slate-400">AI Classification:</span> <span className="text-white font-bold">{selectedAlertModal.classification} ({selectedAlertModal.confidence})</span></div>
                <div className="pt-2 border-t border-slate-800">
                  <span className="text-slate-400 block mb-1">Telemetry Description:</span>
                  <p className="text-slate-200 bg-slate-900 p-2 rounded border border-slate-800 text-[11px] leading-relaxed">{selectedAlertModal.msg}</p>
                </div>
              </div>

              <div className="flex gap-3 pt-1">
                <button 
                  onClick={() => {
                    triggerAlarm(alarmDuration);
                    setSelectedAlertModal(null);
                  }}
                  className="flex-1 bg-red-600 hover:bg-red-700 text-white font-mono font-bold text-xs py-2.5 px-4 rounded-lg flex items-center justify-center gap-2 shadow-lg">
                  <Volume2 className="w-4 h-4"/> SOUND {alarmDuration}S SIREN
                </button>
                <button 
                  onClick={() => setSelectedAlertModal(null)}
                  className="bg-slate-800 hover:bg-slate-700 text-slate-300 font-mono text-xs py-2.5 px-4 rounded-lg border border-slate-700">
                  ACKNOWLEDGE RECORD
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
